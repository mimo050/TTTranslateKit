# TTTranslateKit
Use GitHub Actions to build TTTranslateKit.dylib then inject with ESign.
